async function checkProjects() {
    const res = await fetch('http://localhost:5000/api/state', {
        headers: { 'x-api-key': 'dotcolor_sec_key_9f82d1c6e4' }
    });
    const { data: d } = await res.json();
    console.log('Projects count:', d.projects.length);
    d.projects.forEach((p: any) => {
        console.log({
            id: p.id,
            code: p.code,
            name: p.name,
            totalSales: p.totalSales,
            totalExpenses: p.totalExpenses,
            invoiceNo: p.invoiceNo
        });
    });
}
checkProjects();
