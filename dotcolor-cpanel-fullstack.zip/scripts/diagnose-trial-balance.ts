async function check() {
    const res = await fetch('http://localhost:5000/api/state', {
        headers: { 'x-api-key': 'dotcolor_sec_key_9f82d1c6e4' }
    });
    const { data: d } = await res.json();
    const inv = d.invoices.find((i: any) => i.invoiceNo === 'DCC-INV-2026-9627');
    console.log('Invoice DCC-INV-2026-9627:', JSON.stringify(inv, null, 2));
    
    console.log('\n--- ALL INVOICES ---');
    d.invoices.forEach((i: any) => console.log(i.invoiceNo, 'paid:', i.paidAmount, 'due:', i.dueAmount, 'total:', i.grandTotal, 'split:', i.splitPayments));
    
    console.log('\n--- TRANSACTIONS (LATEST 10) ---');
    d.transactions.slice(0, 10).forEach((t: any) => console.log(t.id, t.date, t.type, t.accountHead, t.amount, t.description));

    console.log('\n--- JOURNAL ENTRIES ---');
    (d.journalEntries || []).forEach((je: any) => console.log(je.entryNo, je.debitAccountName, '->', je.creditAccountName, je.amount, je.narration));

    console.log('\n--- CHART OF ACCOUNTS ---');
    d.chartOfAccounts.forEach((a: any) => console.log(a.code, a.name, a.classification, a.normalBalance, 'open:', a.openingBalance, 'curr:', a.currentBalance));
}

check();
