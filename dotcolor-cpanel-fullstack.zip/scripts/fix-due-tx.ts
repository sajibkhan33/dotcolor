async function fixDueTx() {
    const ERP_API_KEY = 'dotcolor_sec_key_9f82d1c6e4';
    const getRes = await fetch('http://localhost:5000/api/state', {
        headers: { 'x-api-key': ERP_API_KEY }
    });
    const { data: d, revision } = await getRes.json();

    d.transactions = (d.transactions || []).map((t: any) => {
        if (t.refNo === 'DCC-INV-2026-9627' || t.description?.includes('DCC-INV-2026-9627')) {
            return {
                ...t,
                projectId: 'prj-1793434312066',
                projectCode: 'PRJ-2026-2657',
                category: 'Project Due Collection',
                description: `Project Due Collected: [PRJ-2026-2657] Mr Jahid - Invoice #DCC-INV-2026-9627 (${t.accountHead || t.paymentAccount})`
            };
        }
        return t;
    });

    const postRes = await fetch('http://localhost:5000/api/state', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'x-api-key': ERP_API_KEY
        },
        body: JSON.stringify({
            data: d,
            clientRev: revision,
            force: true
        })
    });
    const result = await postRes.json();
    console.log('Result of updating transactions:', result);
}

fixDueTx();
