async function inspectTx() {
    const res = await fetch('http://localhost:5000/api/state', {
        headers: { 'x-api-key': 'dotcolor_sec_key_9f82d1c6e4' }
    });
    const { data: d } = await res.json();
    const txs = d.transactions.filter((t: any) => t.refNo === 'DCC-INV-2026-9627' || t.description?.includes('9627'));
    console.log('Transactions for DCC-INV-2026-9627:');
    console.log(JSON.stringify(txs, null, 2));
}

inspectTx();
