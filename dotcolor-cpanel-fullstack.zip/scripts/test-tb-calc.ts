import { calculateSingleAccountBalance } from '../src/utils/accountUtils';

async function testTrialBalance() {
    const res = await fetch('http://localhost:5000/api/state', {
        headers: { 'x-api-key': 'dotcolor_sec_key_9f82d1c6e4' }
    });
    const { data: d } = await res.json();
    
    d.chartOfAccounts.forEach((acc: any) => {
        const bal = calculateSingleAccountBalance(
            acc,
            d.chartOfAccounts,
            d.transactions,
            d.invoices,
            d.purchaseOrders,
            d.journalEntries,
            d.projects
        );
        console.log(`${acc.code} ${acc.name} (${acc.classification}, ${acc.normalBalance}): bal = ${bal}, currBal = ${acc.currentBalance}`);
    });
}

testTrialBalance();
