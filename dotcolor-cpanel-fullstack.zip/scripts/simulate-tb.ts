import {
    calculateTotalCustomerReceivables,
    calculateTotalSupplierPayables,
    calculateTotalCustomerAdvances,
    calculateSingleAccountBalance,
    isInvoiceTransaction,
    isProjectTransaction,
    isDueReceivableTransaction,
    isAdvanceDepositTransaction,
    isAdvanceAdjustmentTransaction,
    isProjectDueCollectionTransaction
} from '../src/utils/accountUtils';

async function testSimulate() {
    const res = await fetch('http://localhost:5000/api/state', {
        headers: { 'x-api-key': 'dotcolor_sec_key_9f82d1c6e4' }
    });
    const { data: d } = await res.json();
    const {
        chartOfAccounts,
        transactions,
        invoices,
        purchaseOrders,
        journalEntries,
        projects,
        customers,
        suppliers,
        products
    } = d;

    const totalReceivables = calculateTotalCustomerReceivables(invoices, customers, projects);
    const totalPayables = calculateTotalSupplierPayables(suppliers, purchaseOrders);
    const totalAdvances = calculateTotalCustomerAdvances(customers, transactions, chartOfAccounts);

    const closingStockValuation = (products || []).reduce((s: number, p: any) => {
        const qty = (Number(p.stockOffice) || 0) + (Number(p.stockFactory) || 0);
        return s + (qty * (Number(p.costPrice) || 0));
    }, 0);

    const isInvLinkedToProject = (inv: any) => {
        const invNo = (inv.invoiceNo || '').toLowerCase().trim();
        return Boolean(
            inv.projectId ||
            inv.projectCode ||
            (projects || []).some((p: any) => p.id === inv.projectId || p.code === inv.projectCode || (p.invoiceNo && p.invoiceNo.toLowerCase().trim() === invNo))
        );
    };

    const isTxLinkedToProject = (t: any) => {
        if (!t) return false;
        if (isProjectTransaction(t)) return true;
        const ref = (t.refNo || '').toLowerCase().trim();
        if (ref && (invoices || []).some((inv: any) => (inv.invoiceNo || '').toLowerCase().trim() === ref && isInvLinkedToProject(inv))) {
            return true;
        }
        return false;
    };

    const isTxDueCollection = (t: any) => {
        if (!t) return false;
        const cat = (t.category || '').toLowerCase();
        const desc = (t.description || '').toLowerCase();
        return cat.includes('due collection') || desc.includes('due collection') || desc.includes('due collected');
    };

    const totalNonProjectInvoiceSales = (invoices || [])
        .filter((inv: any) => !isInvLinkedToProject(inv))
        .reduce((s: number, inv: any) => s + (Number(inv.grandTotal) || (Number(inv.paidAmount) + Number(inv.dueAmount)) || 0), 0);

    const projectInvoicesTotal = (invoices || [])
        .filter((inv: any) => isInvLinkedToProject(inv))
        .reduce((s: number, inv: any) => s + (Number(inv.grandTotal) || (Number(inv.paidAmount) + Number(inv.dueAmount)) || 0), 0);

    const totalProjectSales = Math.max(
        (projects || []).reduce((s: number, p: any) => s + (Number(p.totalSales) || 0), 0),
        projectInvoicesTotal
    );

    const totalProjectExpenses = (projects || []).reduce((s: number, p: any) => s + (Number(p.totalExpenses) || 0), 0);

    let cogsAssigned = false;
    let totalTbDebits = 0;
    let totalTbCredits = 0;

    (chartOfAccounts || []).forEach((acc: any) => {
        const nameLower = (acc.name || '').toLowerCase().trim();
        let debit = 0;
        let credit = 0;

        if (acc.classification === 'Asset') {
            if (acc.code === '1003' || acc.code === '1050' || nameLower.includes('receivable')) {
                debit = totalReceivables > 0 ? totalReceivables : (acc.openingBalance || 0);
            } else if (acc.code === '1002' || acc.code === '1060' || acc.code === '1070' || nameLower.includes('inventory') || nameLower.includes('stock')) {
                debit = closingStockValuation > 0 ? closingStockValuation : (acc.openingBalance || 0);
            } else {
                debit = calculateSingleAccountBalance(acc, transactions, invoices, projects, journalEntries);
            }
        } else if (acc.classification === 'Liability') {
            if (acc.code === '2001' || acc.code === '2010' || nameLower.includes('payable') || nameLower.includes('supplier')) {
                credit = totalPayables > 0 ? totalPayables : (acc.openingBalance || 0);
            } else if (acc.code === '2002' || acc.code === '2020' || nameLower.includes('advance')) {
                credit = totalAdvances > 0 ? totalAdvances : (acc.currentBalance || acc.openingBalance || 0);
            } else {
                credit = acc.currentBalance || acc.openingBalance || 0;
            }
        } else if (acc.classification === 'Equity') {
            const isDrawings = acc.normalBalance === 'Debit' || nameLower.includes('drawing') || (acc.nameBn || '').includes('উত্তোলন');
            const isRetained = acc.code === '3003' || acc.code === '3020' || nameLower.includes('retained');

            if (isDrawings) {
                let journalDrawingsDelta = 0;
                (journalEntries || []).forEach((j: any) => {
                    if (j.source === 'PROJECT_SALES' || j.source === 'PROJECT_EXPENSE' || j.source === 'EXPENSE' || j.source === 'SALES' || j.source === 'PURCHASE' || j.source === 'LEDGER_SYNC') return;
                    const isDebit = (j.debitAccountId === acc.id || j.debitAccountId === acc.code || (j.debitAccountName && j.debitAccountName.toLowerCase().trim() === nameLower));
                    const isCredit = (j.creditAccountId === acc.id || j.creditAccountId === acc.code || (j.creditAccountName && j.creditAccountName.toLowerCase().trim() === nameLower));
                    const amt = Number(j.amount) || 0;
                    if (isDebit && !isCredit) journalDrawingsDelta += amt;
                    else if (isCredit && !isDebit) journalDrawingsDelta -= amt;
                });
                const txDrawings = (transactions || [])
                    .filter((t: any) => t.type === 'EXPENSE' && ((t.category || '').toLowerCase().includes('drawing') || (t.description || '').toLowerCase().includes('drawing') || (t.accountHead || '').toLowerCase().includes('drawing')))
                    .reduce((s: number, t: any) => s + (Number(t.amount) || 0), 0);
                debit = Math.max(0, (acc.openingBalance || 0) + journalDrawingsDelta + txDrawings);
            } else if (isRetained) {
                credit = Math.max(0, acc.openingBalance || 0);
            } else {
                let journalEquityDelta = 0;
                (journalEntries || []).forEach((j: any) => {
                    if (j.source === 'PROJECT_SALES' || j.source === 'PROJECT_EXPENSE' || j.source === 'EXPENSE' || j.source === 'SALES' || j.source === 'PURCHASE' || j.source === 'LEDGER_SYNC') return;
                    if (j.refNo && (transactions || []).some((t: any) => t.refNo && t.refNo.toLowerCase().trim() === j.refNo.toLowerCase().trim())) return;
                    const isDebit = (j.debitAccountId === acc.id || j.debitAccountId === acc.code || (j.debitAccountName && j.debitAccountName.toLowerCase().trim() === nameLower));
                    const isCredit = (j.creditAccountId === acc.id || j.creditAccountId === acc.code || (j.creditAccountName && j.creditAccountName.toLowerCase().trim() === nameLower));
                    const amt = Number(j.amount) || 0;
                    if (isCredit && !isDebit) journalEquityDelta += amt;
                    else if (isDebit && !isCredit) journalEquityDelta -= amt;
                });
                const baseCap = (journalEquityDelta > 0) ? (acc.openingBalance || 0) : (acc.openingBalance || acc.currentBalance || 0);
                credit = Math.max(0, baseCap + journalEquityDelta);
            }
        } else if (acc.classification === 'Revenue') {
            const isPrj = acc.code === '4002' || acc.code === '4051' || acc.code === '4060' || nameLower.includes('project');
            if (isPrj) {
                const standalonePrjTxSales = (transactions || [])
                    .filter((t: any) => t.type === 'INCOME' && !isDueReceivableTransaction(t) && !isAdvanceDepositTransaction(t) && !isAdvanceAdjustmentTransaction(t) && !isProjectDueCollectionTransaction(t) && (
                        isProjectTransaction(t) || 
                        (t.category && t.category.toLowerCase().includes('project')) ||
                        (t.accountHead && t.accountHead.toLowerCase().includes('project')) ||
                        (t.refNo && t.refNo.toUpperCase().startsWith('PRJ-'))
                    ) && !(projects || []).some((p: any) => 
                        (p.code && t.refNo && p.code.toLowerCase() === t.refNo.toLowerCase()) || 
                        (p.code && t.description && t.description.toLowerCase().includes(p.code.toLowerCase())) ||
                        (p.invoiceNo && t.refNo && p.invoiceNo.toLowerCase() === t.refNo.toLowerCase()) ||
                        (p.invoiceNo && t.description && t.description.toLowerCase().includes(p.invoiceNo.toLowerCase()))
                    ))
                    .reduce((s: number, t: any) => s + (Number(t.amount) || 0), 0);

                const effectivePrjRevenue = (projects && projects.length > 0)
                    ? (totalProjectSales + standalonePrjTxSales)
                    : (transactions || [])
                        .filter((t: any) => t.type === 'INCOME' && !isDueReceivableTransaction(t) && !isAdvanceDepositTransaction(t) && !isAdvanceAdjustmentTransaction(t) && !isProjectDueCollectionTransaction(t) && (
                            isProjectTransaction(t) || 
                            (t.category && t.category.toLowerCase().includes('project')) ||
                            (t.accountHead && t.accountHead.toLowerCase().includes('project')) ||
                            (t.refNo && (t.refNo.toUpperCase().startsWith('PRJ-') || (projects || []).some((p: any) => p.code === t.refNo)))
                        ))
                        .reduce((s: number, t: any) => s + (Number(t.amount) || 0), 0);

                credit = (acc.openingBalance || 0) + effectivePrjRevenue;
            } else if (acc.code === '4001' || acc.code === '4010' || nameLower.includes('sales')) {
                // Non-project general sales: strictly exclude project-linked transactions and due collection settlements
                const invoiceSalesFromTx = (transactions || [])
                    .filter((t: any) => 
                        t.type === 'INCOME' && 
                        isInvoiceTransaction(t) && 
                        !isTxLinkedToProject(t) &&
                        !isTxDueCollection(t) &&
                        !(t.category || '').toLowerCase().includes('project') && 
                        !(t.refNo || '').toUpperCase().startsWith('COL-') && 
                        !(t.refNo || '').toUpperCase().startsWith('PRJ-')
                    )
                    .reduce((s: number, t: any) => s + (Number(t.amount) || 0), 0);
                const effectiveInvoiceSales = Math.max(totalNonProjectInvoiceSales, invoiceSalesFromTx);

                const directMatchingSales = (transactions || [])
                    .filter((t: any) => 
                        t.type === 'INCOME' && 
                        !isInvoiceTransaction(t) && 
                        !isTxLinkedToProject(t) &&
                        !isTxDueCollection(t) &&
                        !isDueReceivableTransaction(t) && 
                        !isAdvanceDepositTransaction(t) && 
                        !isAdvanceAdjustmentTransaction(t) && 
                        !(t.category || '').toLowerCase().includes('project') &&
                        !(t.refNo || '').toUpperCase().startsWith('COL-') && 
                        !(t.refNo || '').toUpperCase().startsWith('PRJ-') &&
                        (
                            (t.category && (nameLower.includes(t.category.toLowerCase()) || t.category.toLowerCase().includes('sales'))) ||
                            (t.accountHead && (nameLower.includes(t.accountHead.toLowerCase()) || t.accountHead.toLowerCase().includes('sales')))
                        ) &&
                        !(chartOfAccounts || []).some((otherAcc: any) => 
                            otherAcc.id !== acc.id && 
                            otherAcc.classification === 'Revenue' && 
                            (
                                (t.category && otherAcc.name.toLowerCase() === t.category.toLowerCase()) ||
                                (t.accountHead && otherAcc.name.toLowerCase() === t.accountHead.toLowerCase())
                            )
                        )
                    )
                    .reduce((s: number, t: any) => s + (Number(t.amount) || 0), 0);

                credit = (acc.openingBalance || 0) + effectiveInvoiceSales + directMatchingSales;
            } else {
                credit = (acc.openingBalance || 0) + (acc.currentBalance || 0);
            }
        } else if (acc.classification === 'Expense') {
            const isCogs = (
                acc.code === '5001' ||
                acc.code === '5010' ||
                acc.id === 'coa-5001' ||
                acc.id === 'coa-5010' ||
                nameLower.includes('cost of goods') ||
                nameLower.includes('cogs') ||
                (acc.nameBn || '').includes('বিক্রিত পণ্যের ব্যয়')
            );
            const isProjectExp = (
                acc.code === '5206' ||
                acc.id === 'coa-5206' ||
                nameLower.includes('project')
            );

            if (isCogs && !cogsAssigned) {
                cogsAssigned = true;
                const costOfGoodsSold = (purchaseOrders || []).filter((po: any) => po.status === 'Received').reduce((s: number, po: any) => s + (Number(po.grandTotal) || Number(po.totalAmount) || 0), 0) - closingStockValuation;
                debit = costOfGoodsSold > 0 ? costOfGoodsSold : ((acc.openingBalance || 0) + (acc.currentBalance || 0));
            } else if (isProjectExp) {
                const projectMatching = (transactions || [])
                    .filter((t: any) => t.type === 'EXPENSE' && (
                        isProjectTransaction(t) ||
                        (t.category && t.category.toLowerCase().includes('project')) ||
                        (t.accountHead && t.accountHead.toLowerCase().includes('project')) ||
                        (t.refNo && (t.refNo.startsWith('PRJ-') || (projects || []).some((p: any) => p.code === t.refNo)))
                    ))
                    .reduce((s: number, t: any) => s + (Number(t.amount) || 0), 0);
                debit = (acc.openingBalance || 0) + Math.max(projectMatching, totalProjectExpenses, (acc.currentBalance || 0));
            } else {
                debit = (acc.openingBalance || 0) + (acc.currentBalance || 0);
            }
        }

        if (debit > 0 || credit > 0) {
            console.log(`${acc.code} ${acc.name}: Debit=${debit}, Credit=${credit}`);
            totalTbDebits += debit;
            totalTbCredits += credit;
        }
    });

    console.log('==================================================');
    console.log(`TOTAL DEBITS:  ৳${totalTbDebits.toLocaleString()}`);
    console.log(`TOTAL CREDITS: ৳${totalTbCredits.toLocaleString()}`);
    console.log(`OUT OF BALANCE: ৳${(totalTbCredits - totalTbDebits).toLocaleString()}`);
}

testSimulate();
