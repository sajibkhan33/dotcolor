import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { BrandLogo } from './BrandLogo';
import { Lock, Eye, EyeOff, AlertCircle, CheckCircle, ArrowRight, Languages } from 'lucide-react';

export const Login: React.FC = () => {
    const { login, language, setLanguage } = useApp();
    const [pin, setPin] = useState<string>('');
    const [showPin, setShowPin] = useState<boolean>(false);
    const [error, setError] = useState<string>('');
    const [success, setSuccess] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const isBn = language === 'bn';

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const trimmedPin = pin.trim();
        if (!trimmedPin) {
            setError(isBn ? 'অনুগ্রহ করে আপনার পিন কোড লিখুন' : 'Please enter your PIN code');
            return;
        }

        setError('');
        setSuccess('');
        setIsLoading(true);

        setTimeout(() => {
            const res = login(trimmedPin);
            setIsLoading(false);
            if (res.success) {
                setSuccess(res.message);
            } else {
                setError(res.message);
            }
        }, 200);
    };

    return (
        <div className="min-h-screen bg-slate-50 flex flex-col justify-center items-center py-10 px-4 sm:px-6 font-sans selection:bg-amber-100 selection:text-amber-900 relative">
            {/* Language Toggle */}
            <div className="absolute top-4 right-4">
                <button
                    type="button"
                    onClick={() => setLanguage(isBn ? 'en' : 'bn')}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-200 hover:border-slate-300 text-slate-700 rounded-xl text-xs font-semibold shadow-2xs transition-all cursor-pointer"
                >
                    <Languages className="w-3.5 h-3.5 text-amber-600" />
                    <span>{isBn ? 'English' : 'বাংলা'}</span>
                </button>
            </div>

            {/* Header with Logo */}
            <div className="w-full max-w-md flex flex-col items-center justify-center text-center">
                <BrandLogo size="lg" showTagline={true} />

                <h2 className="mt-5 text-3xl font-extrabold tracking-tight text-slate-900">
                    {isBn ? 'সিস্টেম লগইন' : 'System Login'}
                </h2>
                <p className="mt-2 text-sm text-slate-500 font-medium">
                    {isBn ? 'আপনার পিন কোড দিয়ে লগইন করুন' : 'Enter your PIN code to login'}
                </p>
            </div>

            {/* Login Card */}
            <div className="mt-6 w-full max-w-md bg-white p-7 sm:p-8 rounded-3xl shadow-xs border border-slate-200/80">
                <form className="space-y-5" onSubmit={handleSubmit}>
                    {/* PIN CODE INPUT */}
                    <div>
                        <label
                            htmlFor="pin"
                            className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2"
                        >
                            {isBn ? 'পিন কোড / পাসওয়ার্ড' : 'PIN CODE'}
                        </label>
                        <div className="relative rounded-2xl">
                            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                                <Lock className="h-4 w-4 text-slate-400" />
                            </div>
                            <input
                                id="pin"
                                name="pin"
                                type={showPin ? 'text' : 'password'}
                                required
                                autoFocus
                                value={pin}
                                onChange={(e) => setPin(e.target.value)}
                                placeholder={isBn ? 'আপনার পিন কোড লিখুন' : 'Enter your PIN code'}
                                className="block w-full pl-10 pr-10 py-3.5 bg-slate-50/50 border border-slate-200 rounded-2xl text-slate-950 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-amber-500 focus:bg-white text-sm font-medium tracking-wider transition-all"
                            />
                            <button
                                type="button"
                                onClick={() => setShowPin(!showPin)}
                                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                                aria-label={showPin ? 'Hide PIN' : 'Show PIN'}
                            >
                                {showPin ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                            </button>
                        </div>
                    </div>

                    {/* Error & Success Alerts */}
                    {error && (
                        <div className="flex items-center gap-2 p-3 bg-rose-50 text-rose-700 rounded-2xl text-xs border border-rose-200/80 transition-all">
                            <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
                            <span className="font-semibold">{error}</span>
                        </div>
                    )}
                    {success && (
                        <div className="flex items-center gap-2 p-3 bg-emerald-50 text-emerald-700 rounded-2xl text-xs border border-emerald-200/80 transition-all">
                            <CheckCircle className="w-4 h-4 shrink-0 text-emerald-500" />
                            <span className="font-semibold">{success}</span>
                        </div>
                    )}

                    {/* Submit Log In Button */}
                    <div>
                        <button
                            type="submit"
                            disabled={isLoading}
                            className="w-full flex justify-center items-center gap-2 py-3.5 px-6 rounded-2xl text-base font-bold text-white bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 shadow-sm active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed transition-all cursor-pointer"
                        >
                            {isLoading ? (
                                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                            ) : (
                                <>
                                    <span>{isBn ? 'লগইন করুন' : 'Log In'}</span>
                                    <ArrowRight className="w-5 h-5" />
                                </>
                            )}
                        </button>
                    </div>
                </form>
            </div>

            {/* Powered by BD HOSTT IT Partner Promotion */}
            <div className="mt-8 text-center flex flex-col items-center max-w-lg px-4">
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/80 hover:bg-white border border-slate-200/80 shadow-2xs text-xs transition-all">
                    <span className="text-slate-500 font-medium">Developed &amp; Powered by</span>
                    <a
                        href="https://www.bdhost.com"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-extrabold text-blue-600 hover:text-blue-700 flex items-center gap-1.5"
                    >
                        <span>BD HOSTT</span>
                        <span className="text-[10px] font-bold text-amber-700 bg-amber-100/80 px-2 py-0.5 rounded-full">
                            IT Solutions
                        </span>
                    </a>
                </div>
                <p className="text-[11px] text-slate-400 mt-2 font-medium">
                    Web Hosting • Domain Registration • Cloud VPS • Custom ERP &amp; POS Systems
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                    Hotline: <strong className="text-slate-600 font-semibold">01846100900, 01756007600</strong> •{' '}
                    <a
                        href="https://www.bdhost.com"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:underline"
                    >
                        www.bdhost.com
                    </a>
                </p>
            </div>
        </div>
    );
};
